// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore} from 'firebase/firestore'
import {getAuth, GoogleAuthProvider} from 'firebase/auth'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAuetp7l28OU3eVydN4LszEYxeZJyHbEEI",
  authDomain: "aihe5-9927d.firebaseapp.com",
  projectId: "aihe5-9927d",
  storageBucket: "aihe5-9927d.appspot.com",
  messagingSenderId: "619626743836",
  appId: "1:619626743836:web:2d491509ab87e40ecdb7d9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();