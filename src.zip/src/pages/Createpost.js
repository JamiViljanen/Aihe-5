import React, { useEffect, useState } from 'react';
import { addDoc, collection } from 'firebase/firestore';
import { db, auth, storage } from "../firebase-config";
import { useNavigate } from "react-router-dom";
import {
    ref,
    uploadBytes,
    getDownloadURL,
    listAll,
    list
} from "firebase/storage";
import { v4 } from "uuid";

function Createpost({ isAuth }) {
    const [title, setTitle] = useState("");
    const [postText, setPostText] = useState("");
    const [imageUpload, setImageUpload] = useState(null);
    const [imageUrls, setImageUrls] = useState("");

    const imagesListRef = ref(storage, "images/");
    const uploadFile = () => {
        if (imageUpload == null) return;
        const imageRef = ref(storage, `images/${imageUpload.name + v4()}`);
        uploadBytes(imageRef, imageUpload).then((snapshot) => {
            getDownloadURL(snapshot.ref).then((url) => {
                setImageUrls(url);
            });
        });
    };

    const postsCollectionRef = collection(db, "posts");
    let navigate = useNavigate();

    const today = new Date();
    var day = today.getDate();
    var month = today.getMonth() + 1;
    var year = today.getFullYear();
    var postDate = day + '.' + month + '.' + year;

    const createPost = async () => {
        if (auth.currentUser) {
                await addDoc(postsCollectionRef, {
                    title,
                    postDate,
                    postText,
                    imageUrls,
                    author: {
                        name: auth.currentUser.displayName,
                        id: auth.currentUser.uid
                    }
                });
            navigate("/");
        } else {
            console.log("User is not authenticated.");
        }
    };

    useEffect(() => {
        if (!isAuth) {
            navigate("/login");
        }
    }, []);

    return (
        <div className="createPostPage">
            <div className="cpContainer">
                <h1>Create A Post</h1>
                <div className="inputGp">
                    <label> Title:</label>
                    <input placeholder="Title..." onChange={(event) => { setTitle(event.target.value); }} />
                </div>
                <div className="inputGp">
                    <label> Post:</label>
                    <textarea placeholder="Post..." onChange={(event) => { setPostText(event.target.value); }} />
                </div>
                <div className="imageinput">
                    <input
                        type="file"
                        onChange={(event) => {
                            setImageUpload(event.target.files[0]);
                        }}
                    />
                    <button onClick={uploadFile}> Upload Image</button>

                </div>
                <button onClick={createPost}> Submit Post </button>
            </div>
        </div>
    );
}

export default Createpost;
