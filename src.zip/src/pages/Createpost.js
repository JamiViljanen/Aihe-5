import React, { useEffect, useState } from 'react';
import { addDoc, collection } from 'firebase/firestore';
import { db, auth } from "../firebase-config";
import { useNavigate } from "react-router-dom";
import { cleanup } from '@testing-library/react';

function Createpost({ isAuth }) {
    const [title, setTitle] = useState("");
    const [postText, setPostText] = useState("");

    const postsCollectionRef = collection(db, "posts");
    let navigate = useNavigate();

    const today = new Date();
    var day = today.getDate();
    var month = today.getMonth() + 1;
    var year = today.getFullYear();
    var postDate = day + '.' + month + '.' + year;
    /* const createPost = async () => {
        await addDoc(postsCollectionRef, {title, postDate, postText, author: {name: auth.currentUser.displayName, id: auth.currentUser.uid}});
        navigate("/");
    };*/
    const createPost = async () => {
        if (auth.currentUser) {
            await addDoc(postsCollectionRef, {
                title,
                postDate,
                postText,
                author: {
                    name: auth.currentUser.displayName,
                    id: auth.currentUser.uid
                }
            });
            navigate("/");
        } else {
            // Handle the case where the user is not authenticated, e.g., display an error message or redirect them to the login page.
            console.log("User is not authenticated.");
            // You might want to handle this differently depending on your application's requirements.
        }
    };

    useEffect(() => {
        if (!isAuth) {
            navigate("/login");
        }
    }, []);

  return(
    <div className="createPostPage"> 
        <div className="cpContainer">
            <h1>Create A Post</h1>
            <div className="inputGp">
                <label> Title:</label>
                <input placeholder="Title..."  onChange={(event)=> {setTitle(event.target.value);}}/>
            </div>
            <div className="inputGp">
                <label> Post:</label>
                <textarea placeholder="Post..." onChange={(event)=> {setPostText(event.target.value);}}/>
            </div>
            <button onClick={createPost}> Submit Post </button>
        </div>
    </div>
  )
}
export default Createpost;