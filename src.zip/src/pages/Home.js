import React, { useEffect, useState } from 'react';
import { getDocs, collection } from 'firebase/firestore'
import { db } from '../firebase-config'

function Home() {

  const [postLists, setPostList] = useState([]);
  const postsCollectionRef = collection(db, "posts");

  useEffect(() => {
    const getPosts = async () => {
      const data = await getDocs(postsCollectionRef);
      setPostList(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
    }
    
    getPosts();
  }, []);

  return (
    <>
      <div id="title"></div>
      <div className="sideList">
        {postLists.map((post) => {
          return (
            <div key={post.id}>
              <div className="list">
                <a href={`#${post.title}`}><h3>• {post.title}</h3></a>
              </div>
            </div>
          );
        })}
      </div>
      <div className="homePage">
        {postLists.map((post) => {
          return (
            <div className="post" key={post.id}>
              <div className="postHeader">
                <div className="title">
                  <h1 id={post.title}>{post.title}</h1>
                </div>
              </div>
              <div className="postTextContainer">{post.postText}</div>
              {post.imageUrls ? (
                <div className="postImage">
                  <img src={post.imageUrls}/>
                </div>
              ) : null}
              <h3>
                &#128465; {post.author && post.author.name ? `@${post.author.name}` : 'Unknown Author'} &#128465; {post.postDate}
              </h3>
            </div>
          );
        })}
      </div>
    </>
  )
}

export default Home;
